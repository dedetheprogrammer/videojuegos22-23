Dokash, Devid               780131          Tiempo invertido:   7 horas
Lardies Getan, Alberto      735976          Tiempo invertido:   7 horas
Pérez Martínez, Alvaro      781035          Tiempo invertido:   7 horas